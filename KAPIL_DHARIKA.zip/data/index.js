const usersData = require("./user");

module.exports = {
    user: usersData
};